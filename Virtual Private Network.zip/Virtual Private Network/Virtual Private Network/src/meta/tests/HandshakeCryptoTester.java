package meta.tests;

public class HandshakeCryptoTester {
    static String PRIVATEKEYFILE = "certs/CAPrivateKey.der";
    static String CERTFILE = "certs/CA.pem";
    static String PLAINTEXT = "Time flies like an arrow. Fruit flies like a banana.";
    static String ENCODING = "UTF-8";

    static public void run() throws Exception {
    }
}