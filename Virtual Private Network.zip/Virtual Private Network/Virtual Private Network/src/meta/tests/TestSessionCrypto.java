package meta.tests;

import communication.session.SessionDecrypter;
import communication.session.SessionEncrypter;

import java.io.*;
import javax.crypto.*;

public class TestSessionCrypto  {
    static String PLAININPUT = "plaininput";
    static String PLAINOUTPUT = "plainoutput";
    static String CIPHER = "cipher";
    static Integer KEYLENGTH = 128;

    public void run() throws Exception {
        int b;

        System.out.format("Encryption and decryption done. Check that \"%s\" and \"%s\" are identical!\n", PLAININPUT, PLAINOUTPUT);
    }
}